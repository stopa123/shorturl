/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.springbootappvone;

import com.mycompany.springbootappvone.myMethods.urlShortener;
import java.net.MalformedURLException;
import java.net.URI;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 *
 * @author sikhu
 */
@Controller
public class maincontroller {// 2132742241 | 2132604784

    @Autowired
    public Repo repo;

    @RequestMapping(value = "/posturl", method = RequestMethod.POST)
    @ResponseBody
    public String POSTM(@RequestBody urlShortener us) { //https request not http

        urlShortener plz = new urlShortener(); //generate short URL using empty Constructor.
        urlShortener longURL = new urlShortener(us.getShortener(), plz.getShortener()); //constructor to save into Database
        repo.save(longURL);

        //myMethods.urlShortener.sendEmail(plz.getShortener(), "sikhuliso@gmail.com", "Post method Logs", "This is Post Method Email"); //send URL to email
        String redirectShort = us.getShortener();

        return redirectShort;
    }

    @ResponseBody
    @RequestMapping(value = "/geturl", method = RequestMethod.GET)
    public String GETM(@RequestBody urlShortener us) throws MalformedURLException {
        Optional<urlShortener> data = repo.findUrlByShortener(us.getShortener());

        String getURL = null;

        if (data.isPresent()) {
            us = data.get(); //get data
            getURL = us.getUrl(); //get url as string from data.
            myMethods.urlShortener.sendEmail(us.getUrl(), "sikhuliso@gmail.com", "Get method Logs", "This is Get Method Email"); //send URL to email
        } else {

        }
        return getURL; //getData; 
    }

    @GetMapping("/redirect")
    public Mono<Void> redirectToAnotherUrl(ServerWebExchange exchange) {
        
        String redirectUrl = "https://www.cashbackforex.com/tools/pip-calculator?s=XAU.USD";// Redirect to another URL
       
        exchange.getResponse().setStatusCode(HttpStatus.FOUND); // Set HTTP status code to 302 (Found) for redirection
        exchange.getResponse().getHeaders().setLocation(URI.create(redirectUrl));
        
        return exchange.getResponse().setComplete();// End response processing
    }

    @ResponseBody
    @RequestMapping(value = "/deleteurl", method = RequestMethod.DELETE)
    public Integer DELETEM(@RequestBody urlShortener us) throws MalformedURLException {
        Optional<urlShortener> data = repo.findUrlByShortener(us.getShortener());
        long id = 0;
        Integer idd = (int) id;

        if (data.isPresent()) {
            us = data.get();
            idd = us.getId();
            repo.deleteById(idd);
            myMethods.urlShortener.sendEmail(us.getShortener() + " has been deleted.", "sikhuliso@gmail.com", "Delete method Logs", "This is Delete Method Email"); //send URL to email

        } else {
        }
        return idd; //getData;
    }

}
