package com.mycompany.springbootappvone;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

//@RestController
@SpringBootApplication
@EntityScan("com.mycompany.springbootappvone")
public class SpringbootAppVOne {

    private static final Logger logger = Logger.getLogger(SpringbootAppVOne.class.getName());

    public static void main(String[] args) {
        SpringApplication.run(SpringbootAppVOne.class, args);

        logger.log(Level.SEVERE, "error log");
        logger.log(Level.WARNING, "warning log");
        logger.log(Level.INFO, "info log");
        logger.log(Level.FINE, "debug log");
        logger.log(Level.FINER, "trace log");
    }

}
