/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.springbootappvone;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 *
 * @author sikhu
 */
@EnableJpaRepositories(basePackages = "com.mycompany.springbootappvone")
public class JpaConfig {
    
}
