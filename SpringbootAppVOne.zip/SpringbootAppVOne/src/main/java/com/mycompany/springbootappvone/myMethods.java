package com.mycompany.springbootappvone;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.net.URL;
import java.util.HashMap;
import java.util.UUID;

public class myMethods {

    protected static HashMap<String, URL> shortURL = new HashMap<>(); //url hashmap

    @Entity
    public class urlShortener {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private URL url;
        private String shortener = "https://www.vinnoce.com/" + UUID.randomUUID().toString();

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public URL getUrl() {
            return url;
        }

        public void setUrl(URL url) {
            this.url = url;
        }

        public String getShortener() {
            return shortener;
        }

        public void setShortener(String shortener) {
            this.shortener = shortener;
        }

        //constructor
        public urlShortener(URL url, String shortener) {
            super();
            this.url = url;
            this.shortener = shortener;
        }

    }

}
