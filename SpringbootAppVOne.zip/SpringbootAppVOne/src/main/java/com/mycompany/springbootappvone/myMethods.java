package com.mycompany.springbootappvone;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Properties;
import javax.crypto.KeyGenerator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class myMethods {

    protected static HashMap<String, URL> shortURL = new HashMap<>(); //url hashmap

    @Entity()
    public static final class urlShortener {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Integer id;

        static private String recipient, sender;
        private String url;
        private String shortener = "https://www.vinnoce.com/" + Key();

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getShortener() {
            return shortener;
        }

        public void setShortener(String shortener) {
            this.shortener = shortener;
        }

        //constructor
        public urlShortener(String url, String shortener) {
            super();
            this.url = url;
            this.shortener = shortener;
        }

        public urlShortener(String url) {
            super();
            this.url = url;
        }

        public urlShortener() {
            super();
            this.url = getUrl();
            this.shortener = getShortener();
        }

        public static String Key() { //random number
            KeyGenerator kg = null;

            try {
                kg = KeyGenerator.getInstance("AES");
                kg.init(256);

            } catch (NoSuchAlgorithmException e) {
                sendEmail(e, "Key Generator Error", "Please find Error Logs for key Generator", "sikhuliso@gmail.com", "sikhuliso@gmail.com");
            }
            String key = String.valueOf(kg.generateKey());
            String substring = key.substring(key.indexOf("@") + 1);

            return substring;

        }

        public static String sendEmail(String shortener, String reciever, String subject, String bodyText) { //this method is used to send emails of short link with customer email address

            sender = reciever;
            recipient = reciever;

            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "465");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.ssl.enable", "true");
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");
            props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

            props.put("mail.smtp.connectiontimeout", "5000");
            props.put("mail.smtp.timeout", "5000");
            props.put("mail.debug", "true");

            Session ses = Session.getInstance(props, new javax.mail.Authenticator() {

                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(sender, "dtfr hkhp fdlf umit");
                }
            });

            try {

                MimeMessage message = new MimeMessage(ses);// MimeMessage object.
                message.setFrom(new InternetAddress(sender));// Set From Field: adding senders email to from field. 
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));// Set To Field: adding recipient's email to from field.
                message.setSubject(subject);// Set Subject: subject of the email 
                message.setText(bodyText + "\n" + shortener);// set body of the email.
                Transport.send(message);// Send email.

            } catch (MessagingException e) {
                System.out.print(e);
            }
            return "Email Sent!";
        }

        public static String sendEmail(Exception Exception, String receiver, String emailer, String subject, String bodyText) { //this method is used to collect Catch error codes logs.

            sender = emailer;
            recipient = receiver;

            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "465");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.ssl.enable", "true");
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");
            props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

            props.put("mail.smtp.connectiontimeout", "5000");
            props.put("mail.smtp.timeout", "5000");
            props.put("mail.debug", "true");

            Session ses = Session.getInstance(props, new javax.mail.Authenticator() {

                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(sender, "dtfr hkhp fdlf umit");
                }
            });

            try {

                MimeMessage message = new MimeMessage(ses);// MimeMessage object.
                message.setFrom(new InternetAddress(sender));// Set From Field: adding senders email to from field. 
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));// Set To Field: adding recipient's email to from field.
                message.setSubject(subject);// Set Subject: subject of the email 
                message.setText(bodyText + "\n" + Exception);// set body of the email.
                Transport.send(message);// Send email.

            } catch (MessagingException e) {
                System.out.print(e);
            }

            return "Email Sent!";

        }

    }

}
