/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.springbootappvone;

import static com.mycompany.springbootappvone.myMethods.shortURL;
import com.mycompany.springbootappvone.myMethods.urlShortener;
import java.net.URL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author sikhu
 */
@Controller
public class maincontroller {

    @Autowired
    public Repo repo;

    @RequestMapping(value = "/")
    public String formPage() {
        return "form";
    }

    @RequestMapping(value = "/getshorturl")
    public String PostUrl() {
        return "formtwo";
    }

    @RequestMapping("/SaveToDB")
    @ResponseBody
    public String SaveToDB(urlShortener us) {
        repo.save(us);
        return "Success";
    }

    /*@RequestMapping(value = "/getUrl", method = RequestMethod.GET)
    public String getUrlFromDB() {

    }*/

    /*
    //POST Method to generate short URL
    @RequestMapping(value = "/shorturl", method = RequestMethod.POST)
    public ResponseEntity<Object> generateShortURL(@RequestBody myMethods.urlShortener urlshort) {
        return new ResponseEntity<>(urlshort.getShortener(), HttpStatus.CREATED);
    }

    //POST URL
    @RequestMapping(value = "/url", method = RequestMethod.POST)
    private ResponseEntity<Object> PostUrl(@RequestBody urlShortener urlshort) {
        shortURL.put(urlshort.getShortener(), urlshort.getUrl());
        return new ResponseEntity<>(urlshort.getShortener(), HttpStatus.CREATED);
    }
     */
}
